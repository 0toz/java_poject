package com.ict03.class04;

public class Ex06_Animal {

	public abstract void sound();
	//
	public abstract void eat();
	public abstract String play();
	
	
}
