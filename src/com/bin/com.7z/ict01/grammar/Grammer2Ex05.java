package com.ict01.grammar;
class Grammer2Ex05{
	public static void main(String[] args){

	String str = "hello java";
	System.out.println(str);


	String k1 = "1000";
	int k2 = 1000;
	System.out.println(k1 + 10);
	System.out.println(k2 + 10);

	int s1 = 20;
	int s2 = 4;
	System.out.println("결과 : " + (s1 +s2));



	}

}
