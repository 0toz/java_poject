package com.ict03.class01;

public class Ex12_main {

	public static void main(String[] args) {
		Ex12 test1 = new Ex12();
	
		System.out.println("�̸� : "+ test1.getName());
		System.out.println("���� : "+ test1.getAge());
		System.out.println("���� : "+ test1.isGender());
				
				
				
				
				
				
				
	}

}
