package com.ict03.class04;

public abstract class Ex05 extends Ex04 {
	
	@Override
	public void pop(){
		
	}

	@Override
	public void sound() {
		
	}
}
