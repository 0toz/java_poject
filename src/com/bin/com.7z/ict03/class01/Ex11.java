package com.ict03.class01;

public class Ex11 {
//	�ο��� : ��
//	ī���ī 3000�� �Ƹ޸�ī�� 2500 ī��� 3500 �ڸ��꽺 3000
//	�ֹ��ϼ��� Ŭ������ ���.
	//private int peopleNum;
	
	private String productName;
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	private int productPrice;
	
	
	
	
	
	
	
	
//	private String cafemoka = "cafemoka";
//	private int cafemokaPrice = 3000;
//	private String americano = "americano";
//	private int americanoPrice = 2500;
//	private String cafelatte = "cafelatte";
//	private int cafelattePrice = 3500;
//	private String jamong = "jamong";
//	private int jamongPrice = 3000;
//	
//	public int getPeopleNum() {
//		return peopleNum;
//	}
//	public void setPeopleNum(int peopleNum) {
//		this.peopleNum = peopleNum;
//	}
//	public String getCafemoka() {
//		return cafemoka;
//	}
//	public void setCafemoka(String cafemoka) {
//		this.cafemoka = cafemoka;
//	}
//	public int getCafemokaPrice() {
//		return cafemokaPrice;
//	}
//	public void setCafemokaPrice(int cafemokaPrice) {
//		this.cafemokaPrice = cafemokaPrice;
//	}
//	public String getAmericano() {
//		return americano;
//	}
//	public void setAmericano(String americano) {
//		this.americano = americano;
//	}
//	public int getAmericanoPrice() {
//		return americanoPrice;
//	}
//	public void setAmericanoPrice(int americanoPrice) {
//		this.americanoPrice = americanoPrice;
//	}
//	public String getCafelatte() {
//		return cafelatte;
//	}
//	public void setCafelatte(String cafelatte) {
//		this.cafelatte = cafelatte;
//	}
//	public int getCafelattePrice() {
//		return cafelattePrice;
//	}
//	public void setCafelattePrice(int cafelattePrice) {
//		this.cafelattePrice = cafelattePrice;
//	}
//	public String getJamong() {
//		return jamong;
//	}
//	public void setJamong(String jamong) {
//		this.jamong = jamong;
//	}
//	public int getJamongPrice() {
//		return jamongPrice;
//	}
//	public void setJamongPrice(int jamongPrice) {
//		this.jamongPrice = jamongPrice;
//	}
	
	
	
	
	
	
	
	
}
