package com.ict02.array;

public class Ex02 {
	public static void main(String[] args) {
		char[] c1= new char[4];
		c1[0] = 'j';
		c1[1] = 'a';
		c1[2] = 'v';
		c1[3] = 'a';
		
		
		for (int i = 0; i < c1.length; i++) {
			System.out.println(c1[i]);
			
		}
		
		String[] msg = {"java", "jsp", "spring", "android"};
		
		
		
	}

}
