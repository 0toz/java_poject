package com.ict03.class01;

public class Ex04 {

	
		int s1 =10;
		int s2 = 5;
		int result = 0;
		
		
	public void plus01() {
		
		result = s1 + s2;
		
	}
	public int sub01() {
		int res = s1 -s2;
		return res;
		
	}
	
	
	
	
	
}
