package com.ict03.class01;

public class Ex08 {
	private String name = "�Ѹ�";
	
	private int age =13;
	
	private double height = 135.15;
	
	private boolean gender = true;
	private char rank = 'A';
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public boolean isGender() {
		return gender;
	}
	public void setGender(boolean gender) {
		this.gender = gender;
	}
	public char getRank() {
		return rank;
	}
	public void setRank(char rank) {
		this.rank = rank;
	}
	
	//getter /setter ȣ��
//	�޴� - �ҽ� - ���ʷ���Ʈ ���ͼ���
	
	
	
}
