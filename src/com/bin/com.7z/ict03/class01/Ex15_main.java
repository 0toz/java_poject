package com.ict03.class01;

public class Ex15_main {
	public static void main(String[] args) {
		Ex15 t1 = new Ex15();
		System.out.println(t1.su1);
		System.out.println(t1.su2);
		System.out.println(Ex15.su2);
		System.out.println();
		
		
		Ex15 t2 = new Ex15();
		System.out.println(t2.su1);
		System.out.println(t2.su2);
		System.out.println(Ex15.su2);
		System.out.println();
		
		
		Ex15 t3 = new Ex15();
		System.out.println(t3.su1);
		System.out.println(t3.su2);
		System.out.println(Ex15.su2);
		System.out.println();
	}
}
