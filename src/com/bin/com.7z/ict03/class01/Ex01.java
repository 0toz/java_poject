package com.ict03.class01;

public class Ex01 {

}
