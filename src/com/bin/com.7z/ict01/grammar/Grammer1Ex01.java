package com.ict01.grammar;
class Grammer1Ex01{
	public static void main(String[] args){
		System.out.println("�ڹ��� ��!");
	}
}
