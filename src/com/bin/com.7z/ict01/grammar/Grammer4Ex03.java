package com.ict01.grammar;
class  Grammer4Ex03
{
	public static void main(String[] args) 
	{
		for (int i = 1; i < 4 ; i++ )
		{
			for (int j =1 ;j < 6 ; j++ )
			{
				System.out.println("i = " + i + " , j = " + j);
			}
		}
	

		for(int i = 1; i < 10; i++){
			for(int j = 1 ; j <10; j++){
				
				System.out.println( i + " *  " + j + " = " + i * j);
			}
		
		}
	
		for(int i = 1; i < 10; i++){
			for(int j = 1 ; j <10; j++){
				
				System.out.print( j + " *  " + i + " = " + i * j + " ");
			}
			System.out.println();
		}
	
System.out.println();System.out.println();


		for(int i = 1; i < 10; i++){
			for(int j = 1 ; j <10; j++){
				
				System.out.print( i + " *  " + j + " = " + i * j + "   ");
			}
			System.out.println();

		}
	
	}
}
