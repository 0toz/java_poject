package com.ict03.class05;

public class Ex07 extends Ex06 {

	
	
}
