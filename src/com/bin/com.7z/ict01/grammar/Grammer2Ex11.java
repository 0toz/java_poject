package com.ict01.grammar;
class Grammer2Ex11{
	public static void main(String[] args){


	int s1 = 10;
	int s2 = 10;


	System.out.println(++ s1 + 2);
	System.out.println(s2++ + 2);
	System.out.println(++ s1 + 2);

	System.out.println("s1 = " + s1);

	System.out.println("s2 = " + s2);






	}
}


