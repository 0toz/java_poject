package com.ict03.class01;

public class Ex05 {

	public int add() {
		int s1 = 10 +1;
		return s1;
		
				
	}
	
	public int add2(int k) {
		int s1 = k + 10;
		return s1 ;
	}

	public int add3(int k1 , int k2) {
		int s1= k1 +k2;
		return s1;
	}
	
	public int add4(int k1, int k2, int k3) {
		int s1 = k1 + k2 + k3;
		return s1;
	}
	
}
