package com.ict01.grammar;
class Grammer2Ex03{

	public static void main(String[] args){
	//������ : �Ҽ����� ���� ����.
	byte s1 = -127;
	System.out.println(s1);

	s1 = -128;

	System.out.println(s1);


	//s1 = -129;
	System.out.println(s1);

	int s3 = 117;
//
 
	long s4 = 119l ;

	long s5 = 119L;

	long s6 = 119;


	//float s7 = 3.14f;
	double s7 = 3.14f;
	float pi= 3.14f;

System.out.println(s7);



	}
}