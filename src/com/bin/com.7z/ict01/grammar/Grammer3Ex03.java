package com.ict01.grammar;
class Ex04 {
	public static boid main(String[] args){

}