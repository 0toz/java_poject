package com.ict03.class01;

public class Ex07 {

		private String name = "ȫ�浿";
		private int age = 25 ;
		private double height = 180.3;
		private char rank = 'A';
	
		
		public String k1 () {
			return name;
		}
		
		public int k2 () {
			return age;
		}
		public double k3() {
			return height;
		}
		public char k4() {
			return rank;
		}
		
		
		public void m1(String t1) {
			name = t1;
		}
		
		public void m2(int t1) {
			age = t1;
		}
		public void m3(double t1) {
			height = t1;
		}
		public void m4(char t1) {
			rank = t1;
		}
		
		
		
		
		
		
		
}
