package com.ict03.class02;

public class Ex05 {

	public static void main(String[] args) {
		
		String msg19 =
	}
}
